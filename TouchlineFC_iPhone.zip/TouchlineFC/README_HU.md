# Touchline FC – iPhone-os 3D focijáték

## Gyors indítás
- Nyisd meg az `index.html` fájlt egy olyan webtárhelyről, amely HTTPS-t használ. A Three.js modult a jsDelivr CDN-ről tölti le, ezért internet szükséges.
- iPhone-on a Safari címsorába a feltöltött `index.html` HTTPS-címét írd be.
- Nyomd meg a **MECCS INDÍTÁSA** gombot.
- Bal oldali virtuális joystick: mozgás. PASSZ és LÖVÉS gomb: labdakezelés.

## Helyi fájl megnyitása
Az iOS Safari a `file://` címről betöltött ES-modulokat biztonsági okokból korlátozhatja. A megbízható futtatáshoz tedd fel a fájlt HTTPS-es statikus tárhelyre (pl. GitHub Pages vagy más statikus hosting), vagy futtasd helyi fejlesztői szerveren.

## Megjegyzések
- Eredeti prototípus, nem hivatalos FIFA-termék.
- 3D grafika Three.js-szel; az első betöltéshez internetkapcsolat szükséges.
- Mobilra optimalizált érintéses irányítás, joystick, passz, lövés, kapuk, AI és eredményjelző.
